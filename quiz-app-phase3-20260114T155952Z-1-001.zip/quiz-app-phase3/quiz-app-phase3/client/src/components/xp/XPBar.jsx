
export default function XPBar({xp}){
 return <div><div style={{width:xp+'%',background:'lime'}}>XP {xp}%</div></div>;
}
