
const r=require('express').Router();
r.get('/login',(req,res)=>{
 res.send('Google OAuth login placeholder');
});
module.exports=r;
